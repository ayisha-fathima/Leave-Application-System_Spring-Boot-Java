package Team4CA.LMS.domain;

public enum Gender {
MALE, FEMALE
}
