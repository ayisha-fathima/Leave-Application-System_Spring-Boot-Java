package Team4CA.LMS.domain;

public enum Role {
	ADMIN, STAFF, MANAGER
}
