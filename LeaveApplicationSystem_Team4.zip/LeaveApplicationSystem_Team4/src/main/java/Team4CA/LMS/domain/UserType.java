package Team4CA.LMS.domain;

public enum UserType {
	STAFF, ADMIN, MANAGER
}
