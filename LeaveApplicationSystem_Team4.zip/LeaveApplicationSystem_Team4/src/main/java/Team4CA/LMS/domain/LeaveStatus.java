package Team4CA.LMS.domain;

public enum LeaveStatus {
APPLIED, APPROVED,REJECTED, DELETED, UPDATED,CANCELLED
}
