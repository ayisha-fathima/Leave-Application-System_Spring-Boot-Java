package Team4CA.LMS.domain;

public enum OvertimeStatus {
	APPLIED, APPROVED,REJECTED, DELETED, UPDATED, CANCELLED
}
