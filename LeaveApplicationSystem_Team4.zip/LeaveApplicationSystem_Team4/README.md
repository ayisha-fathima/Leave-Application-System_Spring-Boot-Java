# LeaveApplicationSystem

Contributors:

Ayisha Fathima

Kyaw Thiha

Ling Teck Moh Benedict

Ngo Vu Hanh Nguyen

Saw Htet Kyaw

Shermaine Lim Si Hui

Yeo Jia Hui
